</div>

<div align="center">
  
# **Equipo Org y Arq de Computadoras - Practica 6** 💾





<b>Carlos Emilio Castañon Maldonado- <em> 319053315 </em>   &   Pablo  César Navarro Santana- <em> 317333091 </em>



[![](https://media.tenor.com/dcpZz7CEJWEAAAAC/spinning-cat-maxwell.gif)](https://www.youtube.com/watch?v=KC6cPq-NmuU)

</div>
  
---

## **Uso**

- Compilar cada archivo desde su respectivo .asm:
  
- Para el Ejercicio 1 el programa se encarga de todo (Hay nula comunicacion con usuario)

- Para los demas programas basta con compilarlos y correrlos para que cada uno pida al usuario los valores con los que va a funcionar el programa

